package com.springboot.departmentservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.departmentservice.entity.Department;

@Repository
public interface DepartmentRepo extends JpaRepository<Department,Long> {

	Department DeleteByDepartmentId(Department department);

	Department updateByDepartmentId(Department department);

	Department findByDepartmentId(Long departmentId);

}
