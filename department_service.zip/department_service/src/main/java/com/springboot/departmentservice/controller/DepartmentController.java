package com.springboot.departmentservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.departmentservice.Service.DepartmentService;
import com.springboot.departmentservice.entity.Department;

import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/departments")
@Slf4j
public class DepartmentController {

	@Autowired
private DepartmentService ds;
	
	@PostMapping("/")
	public Department saveDepartment(@RequestBody Department department) {
	
	//log.info("inside the postmethod");
		return ds.saveDepartment(department);
	}
	
	@GetMapping("/{DepartmentId}")
	public Department findDepartmentById(@PathVariable("DepartmentId")Long DepartmentId) {
	//	Log.info("inside the getmethod");
		return ds.findDepartmentById(DepartmentId);
	}
	@PutMapping("/")
	public Department UpdateDepartmentById(@RequestBody Department department) {
	//	Log.info("inside the putmethod");
		return ds.UpdateDepartmentById(department);
	}
	@DeleteMapping("/")
	public Department DeleteDepartmentById(@RequestBody Department department) {
	//	Log.info("inside the deletemethod");
		return ds.DeleteDepartmentById(department);
	}
}
