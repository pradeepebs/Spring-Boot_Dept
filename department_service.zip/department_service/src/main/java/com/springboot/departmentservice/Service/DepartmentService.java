package com.springboot.departmentservice.Service;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.departmentservice.Repository.DepartmentRepo;
import com.springboot.departmentservice.entity.Department;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DepartmentService {

	@Autowired
private DepartmentRepo DepartmentRepo ;

	public Department saveDepartment(Department department) {
//       log.info("inside savedepartment of deptcontroller");
		return DepartmentRepo.save(department);
	}

	
	public Department findDepartmentById(Long DepartmentId) {
		//log.info("inside savedepartment of deptcontroller");
		return DepartmentRepo.findByDepartmentId(DepartmentId);
	}

	public Department UpdateDepartmentById(Department department) {
	//	log.info("inside savedepartment of deptcontroller");
		return DepartmentRepo.updateByDepartmentId(department);
	}

	public Department DeleteDepartmentById(Department department) {
//		log.info("inside savedepartment of deptcontroller");
		return DepartmentRepo.DeleteByDepartmentId(department);
	}
}
